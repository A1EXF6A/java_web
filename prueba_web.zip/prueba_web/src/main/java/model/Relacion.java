package model;

public class Relacion {
    private String estudiante;
    private String curso;

    // Getters y setters
    public String getEstudiante() { return estudiante; }
    public void setEstudiante(String estudiante) { this.estudiante = estudiante; }

    public String getCurso() { return curso; }
    public void setCurso(String curso) { this.curso = curso; }
}
