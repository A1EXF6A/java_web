/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package service;
import dao.*;
import java.util.List;
import model.*;
/**
 *
 * @author HOME
 */
public class UserService {
 private UserDAO user = new UserDAO();
 
 public List<User> getAll(){
     return user.getAllUsers();
 }
 
 public boolean insert(User user){
     return this.user.saveUser(user);
 }
 
 public boolean update(User user){
     return this.user.updateUser(user);
 }
 
 public boolean delete(String cedula){
     return this.user.deleteUser(cedula);
 }
 
 public boolean deleteU(User user){
     return this.user.deleteUser(user);
 }
 
 public User getByCedula(String cedula) {
    return new UserDAO().getUserByCedula(cedula);
}

}
