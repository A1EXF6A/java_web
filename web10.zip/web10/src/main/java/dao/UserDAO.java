package dao;

import java.util.ArrayList;
import java.util.List;
import model.User;
import util.Conexion;
import java.sql.*;
import javax.swing.JOptionPane;

public class UserDAO {

    public List<User> getAllUsers() {
        List<User> users = new ArrayList<>();
        String sql = "SELECT * FROM estudiante";

        try (Connection conn = Conexion.getConnection(); PreparedStatement ps = conn.prepareStatement(sql); ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                User user = new User();
                user.setCedula(rs.getString("cedula"));
                user.setNombre(rs.getString("nombre"));
                user.setApellido(rs.getString("apellido"));
                user.setDireccion(rs.getString("direccion"));
                user.setTelefono(rs.getString("telefono"));
                users.add(user);
            }

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }

        return users;
    }

    public boolean saveUser(User user) {
        String sql = "Insert into estudiante (cedula,nombre,apellido,direccion,telefono)" + "values (?,?,?,?,?)";
        try (Connection conn = Conexion.getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, user.getCedula());
            ps.setString(2, user.getNombre());
            ps.setString(3, user.getApellido());
            ps.setString(4, user.getDireccion());
            ps.setString(5, user.getTelefono());
            return ps.executeUpdate() > 0;
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
            return false;
        }

    }

    public boolean updateUser(User user) {
        try (Connection conn = Conexion.getConnection(); PreparedStatement ps = conn.prepareStatement(
                "UPDATE estudiante SET nombre=?, apellido=?, direccion=?, telefono=? WHERE cedula=?")) {
            ps.setString(1, user.getNombre());
            ps.setString(2, user.getApellido());
            ps.setString(3, user.getDireccion());
            ps.setString(4, user.getTelefono());
            ps.setString(5, user.getCedula());
            return ps.executeUpdate() > 0;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    public boolean deleteUser(String cedula) {
        try (Connection conn = Conexion.getConnection(); PreparedStatement ps = conn.prepareStatement("DELETE FROM estudiante WHERE cedula=?")) {
            ps.setString(1, cedula);
            return ps.executeUpdate() > 0;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }
    
    public boolean deleteUser(User user){
        String sql = "Delete from estudiante where cedula=?";
        try (Connection conn = Conexion.getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, user.getCedula());
            return ps.executeUpdate() > 0;
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
            return false;
        }
    }
    
    
    public User getUserByCedula(String cedula) {
    String sql = "SELECT * FROM estudiante WHERE cedula = ?";
    try (Connection conn = Conexion.getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {
        ps.setString(1, cedula);
        try (ResultSet rs = ps.executeQuery()) {
            if (rs.next()) {
                User user = new User();
                user.setCedula(rs.getString("cedula"));
                user.setNombre(rs.getString("nombre"));
                user.setApellido(rs.getString("apellido"));
                user.setDireccion(rs.getString("direccion"));
                user.setTelefono(rs.getString("telefono"));
                return user;
            }
        }
    } catch (Exception e) {
        JOptionPane.showMessageDialog(null, e);
    }
    return null;
}

}
