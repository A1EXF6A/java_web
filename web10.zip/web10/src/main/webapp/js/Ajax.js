const API_BASE = 'http://localhost:8084/web10/UserController';
var url;
var dataTable;

$(document).ready(function () {
    inicializarDataTable();
    configurarEventos();
});

function inicializarDataTable() {
    dataTable = $('#dg').DataTable({
        ajax: {
            url: API_BASE,
            type: 'GET',
            dataType: 'json',
            dataSrc: ''
        },
        columns: [
            { data: 'cedula' },
            { data: 'nombre' },
            { data: 'apellido' },
            { data: 'direccion' },
            { data: 'telefono' },
            {
                data: null,
                render: function (data, type, row) {
                    return `
                        <div class="action-buttons">
                            <button class="btn btn-sm btn-warning me-1 btn-editar-fila" data-cedula="${row.cedula}">
                                <i class="fas fa-edit"></i>
                            </button>
                            <button class="btn btn-sm btn-danger btn-eliminar-fila" data-cedula="${row.cedula}">
                                <i class="fas fa-trash"></i>
                            </button>
                        </div>
                    `;
                },
                orderable: false
            }
        ]
    });
}

function configurarEventos() {
    $('#btnNuevo').click(newUser);
    $('#btnEditar').click(editUser);

    $('#btnEliminar').click(function () {
        var row = dataTable.row('.selected').data();
        if (row) {
            deleteRow(row.cedula);
        } else {
            alert('Por favor seleccione un estudiante');
        }
    });

    $('#btnGuardar').click(saveUser);

    $('#dg tbody').on('click', 'tr', function () {
        if ($(this).hasClass('selected')) {
            $(this).removeClass('selected');
        } else {
            dataTable.$('tr.selected').removeClass('selected');
            $(this).addClass('selected');
        }
    });

    $('#dg').on('click', '.btn-editar-fila', function () {
        var cedula = $(this).data('cedula');
        editRow(cedula);
    });

    $('#dg').on('click', '.btn-eliminar-fila', function () {
        var cedula = $(this).data('cedula');
        deleteRow(cedula);
    });
    $('#btnBuscarCedula').click(function () {
    const cedula = $('#buscarCedula').val().trim();

    if (cedula === '') {
        alert('Por favor ingrese una cédula.');
        return;
    }

    $.ajax({
        url: API_BASE + '?cedula=' + cedula,
        type: 'GET',
        dataType: 'json',
        success: function (estudiante) {
            if (estudiante && estudiante.cedula) {
                dataTable.clear().rows.add([estudiante]).draw();
            } else {
                alert('Estudiante no encontrado.');
                dataTable.clear().draw();
            }
        },
        error: function () {
            alert('No hay estudiantes, con esa cedula.');
            dataTable.ajax.url(API_BASE).load(); 
        }
    });
});

$('#btnLimpiarBusqueda').click(function () {
    $('#buscarCedula').val('');
    dataTable.ajax.url(API_BASE).load(); // Vuelve a cargar todos los datos desde el servidor
});

}

function newUser() {
    $('#modalTitle').text('Nuevo Estudiante');
    $('#fm')[0].reset();
    $('#cedula').prop('disabled', false);
    $('#dlg').modal('show');
}

function editUser() {
    var row = dataTable.row('.selected').data();
    if (row) {
        editRow(row.cedula);
    } else {
        alert('Por favor seleccione un estudiante');
    }
}

function editRow(cedula) {
    $.ajax({
        url: API_BASE,
        type: 'GET',
        dataType: 'json',
        success: function (data) {
            var estudiante = data.find(e => e.cedula == cedula);
            if (estudiante) {
                $('#modalTitle').text('Editar Estudiante');
                $('#cedula').val(estudiante.cedula).prop('disabled', true);
                $('#nombre').val(estudiante.nombre);
                $('#apellido').val(estudiante.apellido);
                $('#direccion').val(estudiante.direccion);
                $('#telefono').val(estudiante.telefono);
                $('#dlg').modal('show');
            }
        },
        error: function () {
            alert('Error al cargar datos del estudiante');
        }
    });
}

function saveUser() {
    const isEdit = $('#cedula').prop('disabled');
    const formData = {
        cedula: $('#cedula').val(),
        nombre: $('#nombre').val(),
        apellido: $('#apellido').val(),
        direccion: $('#direccion').val(),
        telefono: $('#telefono').val()
    };

    if (isEdit) {
        $.ajax({
            url: API_BASE,
            type: 'PUT',
            data: JSON.stringify(formData),
            contentType: 'application/json',
            success: function () {
                $('#dlg').modal('hide');
                dataTable.ajax.reload();
                alert('Estudiante actualizado correctamente');
            },
            error: function (xhr, status, error) {
                console.log('Error al actualizar: ' + (xhr.responseText || error));
            }
        });
    } else {
        $.ajax({
            url: API_BASE,
            type: 'POST',
            data: JSON.stringify(formData),
            contentType: 'application/json',
            success: function () {
                $('#dlg').modal('hide');
                dataTable.ajax.reload();
                alert('Estudiante registrado correctamente');
            },
            error: function (xhr, status, error) {
                console.log('Error al guardar: ' + (xhr.responseText || error));
            }
        });
    }
}

function deleteRow(cedula) {
    if (confirm('¿Está seguro de eliminar este estudiante?')) {
        $.ajax({
            url: API_BASE,
            type: 'DELETE',
            data: JSON.stringify({ cedula: cedula }),
            contentType: 'application/json',
            success: function () {
                dataTable.ajax.reload();
                alert('Estudiante eliminado correctamente');
            },
            error: function (xhr, status, error) {
                console.log('Error al eliminar: ' + (xhr.responseText || error));
            }
        });
    }
}
